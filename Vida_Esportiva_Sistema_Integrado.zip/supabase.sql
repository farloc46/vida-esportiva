-- VIDA ESPORTIVA • SUPABASE
-- Execute este script no SQL Editor do Supabase.

create extension if not exists pgcrypto;

create table if not exists public.public_settings (
  id bigint primary key,
  matricula_valor numeric(10,2) not null default 150,
  pix_key text not null default '',
  pix_receiver text not null default 'Vida Esportiva',
  pix_bank text not null default 'Sicoob',
  pix_message text not null default 'Após o pagamento, envie o comprovante por este WhatsApp.',
  whatsapp_template text not null default 'Olá, {responsavel},\n\nAqui é da Escola de Futebol Vida Esportiva.\n\nA mensalidade de {aluno} está programada para {vencimento}.\n\n💰 Valor: {valor}{pix}\n\nSe o pagamento já foi realizado, desconsidere esta mensagem.\n\n⚽ Vida Esportiva',
  admin_whatsapp text not null default ''
);
insert into public.public_settings(id) values (1) on conflict (id) do nothing;

create table if not exists public.matriculas (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  aluno_nome text not null,
  nascimento date not null,
  escola text not null,
  turno text not null,
  categoria text not null,
  profissao_responsavel text not null,
  responsavel_nome text not null,
  responsavel_telefone text not null,
  cpf text not null,
  endereco text not null,
  foto_url text not null,
  matricula_valor numeric(10,2) not null default 150,
  autorizacao_atividade boolean not null default false,
  autorizacao_imagem boolean not null default false,
  autorizacao_dados boolean not null default false,
  data_matricula date not null default current_date
);

alter table public.public_settings enable row level security;
alter table public.matriculas enable row level security;

drop policy if exists "public read settings" on public.public_settings;
create policy "public read settings" on public.public_settings
for select to anon, authenticated using (id=1);

drop policy if exists "public insert matriculas" on public.matriculas;
create policy "public insert matriculas" on public.matriculas
for insert to anon, authenticated
with check (
  autorizacao_atividade=true and
  autorizacao_imagem=true and
  autorizacao_dados=true
);

drop policy if exists "admin read matriculas" on public.matriculas;
create policy "admin read matriculas" on public.matriculas
for select to authenticated using (true);

drop policy if exists "admin update matriculas" on public.matriculas;
create policy "admin update matriculas" on public.matriculas
for update to authenticated using (true) with check (true);

-- Bucket público para as fotos das matrículas.
insert into storage.buckets (id,name,public)
values ('matriculas','matriculas',true)
on conflict (id) do update set public=true;

drop policy if exists "public upload matricula photo" on storage.objects;
create policy "public upload matricula photo" on storage.objects
for insert to anon, authenticated
with check (bucket_id='matriculas');

drop policy if exists "public read matricula photo" on storage.objects;
create policy "public read matricula photo" on storage.objects
for select to anon, authenticated
using (bucket_id='matriculas');

-- IMPORTANTE:
-- O painel administrativo deve ser usado com uma conta autenticada no Supabase.
-- Não coloque a SERVICE_ROLE_KEY no HTML.
